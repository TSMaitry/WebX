/// eslint-disable-next-line no-unused-vars
function clickNowAlgo1(enableScrolling, btnLabel, delayBeginRange, delayEndRange, additionalInfo) {
    // work in progress
    alert('hello');
}